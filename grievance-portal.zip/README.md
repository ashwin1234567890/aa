# JanSamadhan - Central Public Grievance Redressal Portal

A full-stack, responsive, and secure Public Grievance Redressal platform connected to **PostgreSQL** via a **Node.js / Express** backend, featuring **Google Gemini 3 Flash Multilingual NLP**, **Google Neural Indic-NLP Model (v3.5 SOTA)**, **Continuous Speech-to-Text in Native Scripts**, **Community "Me Too" endorsements**, and a **4-Stage Nodal Officer Management Desk**.

---

## 🌟 Architecture & Key Features

### 1. 🤖 SOTA Multilingual Production AI Models
- **Google Gemini 3 Flash Multilingual NLP (`gemini-3-flash-preview`)**:
  - Full multimodal reasoning across 22+ official Indian languages (Tamil, Telugu, Hindi, Bengali, Marathi, Gujarati, Kannada, Malayalam, Punjabi, Odia, Urdu, English, Hinglish).
  - High-accuracy auto-categorization across 12 civic departments with calibrated urgency scores (0–100) and SLA tracking.
  - Verbatim translation of regional petitions into formal, department-ready administrative English.
  - Dynamic subject docket generation tailored to the specific reported incident.
- **Google Neural Indic-NLP Model (v3.5 SOTA Production)**:
  - Zero-dependency built-in engine requiring **no API keys**.
  - Verbatim neural machine translation via Google Neural MT Network with MyMemory secondary fallback.
  - Dual-language vector semantic reasoning across both the native Indic petition and the English translation simultaneously (95%–99% confidence).
- **🎙️ Continuous Speech-to-Text in Native Regional Scripts**:
  - Live word-by-word streaming into the description textarea and glowing live speech box.
  - Transcribes directly in the spoken language's authentic script (Devanagari, Tamil, Telugu, Bengali, Gujarati, Kannada, Gurmukhi, Perso-Arabic).
  - Studio-grade acoustic constraints (`echoCancellation`, `noiseSuppression`, `autoGainControl`, `48,000 Hz`).
  - Supports **OpenAI Whisper-1** for raw backend audio transcription.

### 2. 👥 Community "Me Too" Endorsements & Grievance AI Locality Clusters
- AI groups multi-complainant petitions within the same neighborhood or sector into clustered **Civic Incidents**.
- Affected neighbors can click **"Me Too"** on existing issues to amplify urgency without filing duplicate complaints.
- Endorsement counters sync directly with PostgreSQL in real time via [`/api/incidents/:id/me-too`](server.js).

### 3. 🛠️ 4-Stage Officer Progress Tracker & Case Closure
- Standardized resolution lifecycle:
  `1. Not Started` $\rightarrow$ `2. Acquiring Resources` $\rightarrow$ `3. Processing` $\rightarrow$ `4. Completion with Proof`
- Real-time field worker assignment and physical resolution photo proof with Action Taken Reports (ATR).

### 4. 🗄️ PostgreSQL Relational Data Store
- **`citizens`**: Complainant accounts with bcrypt password hashes, SHA-256 duplicate detection, and masked Aadhaar (`XXXX XXXX 4920`).
- **`officials`**: Administrative nodal officers with 2FA security tokens and department jurisdictions.
- **`grievances`**: 100 seeded realistic petitions with priority levels, assigned workers, file attachments, and resolution proofs.
- **`civic_incidents`**: Clustered neighborhood incidents with real-time Me-Too endorsement counters.

---

## 🚀 How to Run on a Fresh PC

### 1. Prerequisites
- **Node.js**: v18 or higher (Download from [nodejs.org](https://nodejs.org))
- **PostgreSQL**: v14 or higher (Download from [postgresql.org](https://www.postgresql.org))

### 2. Database Setup
Open **pgAdmin** or `psql` and create the database:
```sql
CREATE DATABASE grievance_portal_db;
```

### 3. Clone / Extract Repository & Install Dependencies
```bash
git clone <your-repository-url>
cd grievance-portal
npm install
```

### 4. Configure Environment Variables
Copy `.env.example` to `.env`:
```bash
cp .env.example .env
```
Update `.env` with your PostgreSQL database password:
```env
PORT=5000
DATABASE_URL=postgresql://postgres:your_password@localhost:5432/grievance_portal_db
JWT_SECRET=jansamadhan-super-secret-key-2026-secure

# Optional: Add your Google Gemini API Key (Free at aistudio.google.com)
GEMINI_API_KEY=your_gemini_api_key_here
GEMINI_MODEL=gemini-3-flash-preview
```

### 5. Start the Application
```bash
npm start
```
*(The server automatically initializes all required tables and seeds 100 sample grievances upon starting).*

Open your browser at: **[http://localhost:5000](http://localhost:5000)**

---

## 🔑 Demo Accounts for Quick Testing

### 1. Citizen Account
- **Identifier**: `9876543210` (or `rajesh.sharma@example.com`)
- **Password**: `Citizen@2026!`
- **Alternative OTP Login**: Mobile `9876543210` with demo OTP `482910`

### 2. Nodal Officer Account
- **Role**: *Nodal Officer / Admin*
- **Identifier**: `EMP-99402` (or `officer@nic.in`)
- **Department**: `Department of Revenue & Land Records` (`revenue`)
- **Security PIN (2FA)**: `482910`
- **Password**: `Officer@2026!`

---

## 📡 REST API Reference

| Method | Endpoint | Description |
|---|---|---|
| `GET` | `/api/health` | Check backend & PostgreSQL connectivity |
| `POST` | `/api/auth/register` | Register citizen with Aadhaar hash & password hashing |
| `POST` | `/api/auth/login` | Authenticate citizen or nodal officer |
| `POST` | `/api/auth/send-otp` | Request mobile verification OTP code |
| `POST` | `/api/auth/verify-otp` | Verify OTP and return citizen session |
| `POST` | `/api/voice/transcribe` | **OpenAI Whisper API** audio transcription & civic auto-categorization |
| `POST` | `/api/incidents/:id/me-too` | Add or remove community "Me Too" endorsement |
| `GET` | `/api/grievances/track/:docketNo` | Query real-time grievance ticket details |
