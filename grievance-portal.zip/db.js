const { Pool } = require('pg');
const bcrypt = require('bcryptjs');
const crypto = require('crypto');
require('dotenv').config();

const connectionString = process.env.DATABASE_URL || 'postgresql://postgres:1234@localhost:5432/grievance_portal_db';

const pool = new Pool({
  connectionString,
  max: 10,
  idleTimeoutMillis: 30000,
  connectionTimeoutMillis: 5000,
});

pool.on('error', (err) => {
  console.error('[PostgreSQL] Unexpected idle client error:', err.message);
});

/**
 * Auto-initialize database tables and seed initial demo data
 */
async function initDb() {
  const client = await pool.connect();
  try {
    console.log('[PostgreSQL] Connected to database. Ensuring tables exist...');

    // 1. Citizens Table
    await client.query(`
      CREATE TABLE IF NOT EXISTS citizens (
        id SERIAL PRIMARY KEY,
        full_name VARCHAR(255) NOT NULL,
        mobile VARCHAR(15) UNIQUE NOT NULL,
        email VARCHAR(255) UNIQUE NOT NULL,
        state VARCHAR(50) NOT NULL,
        category VARCHAR(50) NOT NULL,
        aadhaar_hash VARCHAR(64) NOT NULL,
        aadhaar_masked VARCHAR(20) NOT NULL,
        password_hash VARCHAR(255) NOT NULL,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
      );
    `);

    // 2. Officials Table
    await client.query(`
      CREATE TABLE IF NOT EXISTS officials (
        id SERIAL PRIMARY KEY,
        officer_id VARCHAR(50) UNIQUE NOT NULL,
        name VARCHAR(255) DEFAULT 'Nodal Officer',
        email VARCHAR(255) UNIQUE NOT NULL,
        department VARCHAR(100) NOT NULL,
        security_pin VARCHAR(20) NOT NULL,
        password_hash VARCHAR(255) NOT NULL,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
      );
    `);

    // 3. Grievances Table
    await client.query(`
      CREATE TABLE IF NOT EXISTS grievances (
        id SERIAL PRIMARY KEY,
        docket_no VARCHAR(50) UNIQUE NOT NULL,
        citizen_id INTEGER REFERENCES citizens(id) ON DELETE SET NULL,
        title VARCHAR(255) NOT NULL,
        category VARCHAR(100) NOT NULL,
        department VARCHAR(100) NOT NULL,
        description TEXT,
        priority VARCHAR(50) DEFAULT 'Normal',
        location VARCHAR(255),
        status VARCHAR(50) DEFAULT 'Site Inspection in Progress',
        stage VARCHAR(50) DEFAULT 'Processing',
        stage_step INTEGER DEFAULT 3,
        assigned_officer VARCHAR(255) DEFAULT 'Executive Engineer, Zone 4',
        assigned_worker VARCHAR(255),
        timeline_step INTEGER DEFAULT 3,
        file_name VARCHAR(255),
        file_size VARCHAR(50),
        closure_remarks TEXT,
        closure_proof_url TEXT,
        closed_at TIMESTAMP WITH TIME ZONE,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
      );
    `);

    // Ensure columns exist if table was created in a previous version
    const grievanceColumns = [
      "ALTER TABLE grievances ADD COLUMN IF NOT EXISTS priority VARCHAR(50) DEFAULT 'Normal'",
      "ALTER TABLE grievances ADD COLUMN IF NOT EXISTS location VARCHAR(255)",
      "ALTER TABLE grievances ADD COLUMN IF NOT EXISTS stage VARCHAR(50) DEFAULT 'Processing'",
      "ALTER TABLE grievances ADD COLUMN IF NOT EXISTS stage_step INTEGER DEFAULT 3",
      "ALTER TABLE grievances ADD COLUMN IF NOT EXISTS assigned_worker VARCHAR(255)",
      "ALTER TABLE grievances ADD COLUMN IF NOT EXISTS file_name VARCHAR(255)",
      "ALTER TABLE grievances ADD COLUMN IF NOT EXISTS file_size VARCHAR(50)",
      "ALTER TABLE grievances ADD COLUMN IF NOT EXISTS closure_remarks TEXT",
      "ALTER TABLE grievances ADD COLUMN IF NOT EXISTS closure_proof_url TEXT",
      "ALTER TABLE grievances ADD COLUMN IF NOT EXISTS closed_at TIMESTAMP WITH TIME ZONE"
    ];
    for (const q of grievanceColumns) {
      await client.query(q);
    }

    // 4. Civic Incidents Table
    await client.query(`
      CREATE TABLE IF NOT EXISTS civic_incidents (
        id VARCHAR(50) PRIMARY KEY,
        title VARCHAR(255) NOT NULL,
        description TEXT,
        category VARCHAR(100) NOT NULL,
        category_key VARCHAR(50) NOT NULL,
        location VARCHAR(255) NOT NULL,
        urgency VARCHAR(50) DEFAULT 'High',
        count INTEGER DEFAULT 1,
        me_too_count INTEGER DEFAULT 0,
        is_department BOOLEAN DEFAULT false,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
      );
    `);

    // 5. Seed Demo Nodal Officer if not exists
    const officerCheck = await client.query('SELECT id FROM officials WHERE officer_id = $1', ['EMP-99402']);
    if (officerCheck.rowCount === 0) {
      const hashedOfficerPwd = await bcrypt.hash('Officer@2026!', 10);
      await client.query(`
        INSERT INTO officials (officer_id, name, email, department, security_pin, password_hash)
        VALUES ($1, $2, $3, $4, $5, $6);
      `, ['EMP-99402', 'Dr. Sunita Verma, IAS', 'officer@nic.in', 'revenue', '482910', hashedOfficerPwd]);
      console.log('[PostgreSQL] Seeded demo official: EMP-99402 (officer@nic.in / Officer@2026!)');
    }

    // 6. Seed Demo Citizens if not exist
    const user1Check = await client.query('SELECT id FROM citizens WHERE mobile = $1', ['9812345678']);
    if (user1Check.rowCount === 0) {
      const hashedUser1Pwd = await bcrypt.hash('User@2026!', 10);
      const aadhaarHash1 = crypto.createHash('sha256').update('998877665544').digest('hex');
      await client.query(`
        INSERT INTO citizens (full_name, mobile, email, state, category, aadhaar_hash, aadhaar_masked, password_hash)
        VALUES ($1, $2, $3, $4, $5, $6, $7, $8);
      `, [
        'Priya Sharma',
        '9812345678',
        'user@jansamadhan.in',
        'Delhi NCR',
        'Individual Citizen',
        aadhaarHash1,
        'XXXX XXXX 7721',
        hashedUser1Pwd
      ]);
      console.log('[PostgreSQL] Seeded demo citizen: Priya Sharma (user@jansamadhan.in / User@2026!)');
    }

    const citizenCheck = await client.query('SELECT id FROM citizens WHERE mobile = $1', ['9876543210']);
    if (citizenCheck.rowCount === 0) {
      const hashedCitizenPwd = await bcrypt.hash('Citizen@2026!', 10);
      const aadhaarHash = crypto.createHash('sha256').update('548921044920').digest('hex');
      await client.query(`
        INSERT INTO citizens (full_name, mobile, email, state, category, aadhaar_hash, aadhaar_masked, password_hash)
        VALUES ($1, $2, $3, $4, $5, $6, $7, $8);
      `, [
        'Rajesh Kumar Sharma',
        '9876543210',
        'rajesh.sharma@example.com',
        'Delhi NCR',
        'Individual Citizen',
        aadhaarHash,
        'XXXX XXXX 4920',
        hashedCitizenPwd
      ]);
      console.log('[PostgreSQL] Seeded demo citizen: Rajesh Kumar Sharma (9876543210 / Citizen@2026!)');
    }

    // 7. Seed Demo Grievances if empty or fewer than 50
    const countCheck = await client.query('SELECT count(*) FROM grievances');
    if (parseInt(countCheck.rows[0].count, 10) < 50) {
      const { SEED_GRIEVANCES } = require('./complaints-data');
      const userRes = await client.query('SELECT id FROM citizens WHERE email = $1 LIMIT 1', ['user@jansamadhan.in']);
      const citizenId = userRes.rowCount > 0 ? userRes.rows[0].id : null;
      for (const g of SEED_GRIEVANCES) {
        let timelineStep = 1;
        if (g.status === 'Resolved') timelineStep = 4;
        else if (g.status === 'In Progress') timelineStep = 2;
        await client.query(`
          INSERT INTO grievances (
            docket_no, citizen_id, title, category, department, description, 
            status, assigned_officer, timeline_step, priority, location,
            stage, assigned_worker, file_name, file_size
          )
          VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15)
          ON CONFLICT (docket_no) DO NOTHING;
        `, [
          g.docket_no,
          citizenId,
          g.title,
          g.category,
          g.category_key || 'general',
          g.description,
          g.status,
          g.assigned_officer || 'Executive Engineer',
          timelineStep,
          g.priority || 'Normal',
          g.location || 'New Delhi',
          g.stage || 'Processing',
          g.assigned_worker || null,
          g.fileName || null,
          g.fileSize || null
        ]);
      }
      console.log(`[PostgreSQL] Seeded ${SEED_GRIEVANCES.length} demo grievances.`);
    }

    // 8. Seed Civic Incidents
    const incCount = await client.query('SELECT count(*) FROM civic_incidents');
    if (parseInt(incCount.rows[0].count, 10) === 0) {
      const { SEED_CIVIC_INCIDENTS } = require('./complaints-data');
      for (const inc of SEED_CIVIC_INCIDENTS) {
        await client.query(`
          INSERT INTO civic_incidents (id, title, description, category, category_key, location, urgency, count, me_too_count, is_department)
          VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)
          ON CONFLICT (id) DO NOTHING;
        `, [
          inc.id,
          inc.title,
          inc.description,
          inc.category,
          inc.category_key,
          inc.location,
          inc.urgency,
          inc.count,
          inc.me_too_count || 0,
          inc.is_department || false
        ]);
      }
      console.log(`[PostgreSQL] Seeded ${SEED_CIVIC_INCIDENTS.length} demo civic incidents.`);
    }

    console.log('[PostgreSQL] Database initialization completed successfully.');
  } catch (err) {
    console.error('[PostgreSQL] Error during database initialization:', err);
    throw err;
  } finally {
    client.release();
  }
}

module.exports = {
  pool,
  query: (text, params) => pool.query(text, params),
  initDb,
};
